package steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages.addEmployeepage;
import utils.CommonMethods;

public class addEmployee extends CommonMethods {
    addEmployeepage addEmployeepage = new addEmployeepage();
    @When("user click on PIM option")
    public void user_click_on_pim_option() throws InterruptedException {
       click(addEmployeepage.pimOption);Thread.sleep(2000);

    }
    @When("user click on add employee option")
    public void user_click_on_add_employee_option() throws InterruptedException {
        click(addEmployeepage.addEmployee);
        Thread.sleep(2000);
    }
    @When("user enter firstname and midlename and lastname")
    public void user_enter_firstname_and_midlename_and_lastname() {
        sendText("Aimal",addEmployeepage.firstName);
        sendText("ms" ,addEmployeepage.midletName);
        sendText("Gh",addEmployeepage.lasttName);
    }
    @When("user click on save button")
    public void user_click_on_save_button() {
        WebElement saveButton = driver.findElement(By.xpath("//*[@type='submit']"));
        click(addEmployeepage.saveButton);
    }

    @Then("employee is added successfully")
    public void employee_is_added_successfully() {
        System.out.println("employee added successfully ");
    }
    @When("user enter firstname and midlename and lastname and unique id")
    public void user_enter_firstname_and_midlename_and_lastname_and_unique_id() {
        sendText("Ahmad",addEmployeepage.firstName);
        sendText("ms",addEmployeepage.midletName);
        sendText("kh",addEmployeepage.lasttName);
        sendText("0789",addEmployeepage.employeeid);
    }

}

package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import pages.loginPage;
import utils.CommonMethods;

public class LoginValidation extends CommonMethods {

    @Given("the user is on the HRM login page")
    public void the_user_is_on_the_hrm_login_page() {
        openBrowserAndLaunchApplication();
    }
    @When("the user attemps to log in with an empty username and a valid password")
    public void the_user_attemps_to_log_in_with_an_empty_username_and_a_valid_password() {
        sendText(" ",loginPage.usernameField);
        sendText("Hrm_user@123",loginPage.passwordField);
    }

    @When("the user click on loging button")
    public void the_user_click_on_loging_button() {
        click(loginPage.loginButton);
    }

    @Then("the system displays an error message stating\"Required\"")
    public void the_system_displays_an_error_message_stating_required() {
        String expectedErrorMessage = loginPage . errorMessage.getText();
        Assert.assertEquals("Required",expectedErrorMessage);
        System.out.println("error message is displayed");


    }
    @Then("the user should be able to correct their input and attempt to log in again")
    public void the_user_should_be_able_to_correct_their_input_and_attempt_to_log_in_again() {
        sendText("hrm_user",loginPage.usernameField);
        sendText("Hrm_user@123",loginPage.passwordField);
        click(loginPage.loginButton);
    }

    @When("the user attemps to log in with valid username and emtpy password")
    public void the_user_attemps_to_log_in_with_valid_username_and_emtpy_password() {
        sendText("hrm_user",loginPage.usernameField);
        sendText(" " , loginPage.passwordField);
    }

    @Then("Then the system displays an error message stating\"Required\"")
    public void then_the_system_displays_an_error_message_stating_required() {
        String expectedErrorMessage = loginPage . errorMessage2.getText();
        Assert.assertEquals("Required",expectedErrorMessage);
        System.out.println("error message2 is displayed");

    }

    @When("the user attemps to log in with invalid username and password")
    public void the_user_attemps_to_log_in_with_invalid_username_and_password() {
        sendText("dffdf", loginPage.usernameField);
        sendText("32432",loginPage.passwordField);
    }

    @Then("the system displays an error message stating\"Invalid credentials\"")
    public void the_system_displays_an_error_message_stating_invalid_credentials() {
        String expectedErrorMessage = loginPage . errorMessage3.getText();
        Assert.assertEquals("Invalid credentials",expectedErrorMessage);
        System.out.println("error message3 is displayed");
    }
}



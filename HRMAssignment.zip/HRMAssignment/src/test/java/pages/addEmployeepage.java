package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static utils.CommonMethods.driver;

public class addEmployeepage {
    @FindBy(xpath = "//*[@class='oxd-main-menu-item active']")
    public WebElement pimOption;
    @FindBy(xpath = "//*[text()='Add Employee'][1]")
    public WebElement addEmployee;
    @FindBy(xpath = "//*[@name='firstName']")
    public WebElement firstName;
    @FindBy(xpath = "//*[@name='middleName']")
    public WebElement midletName;
    @FindBy(xpath = "//*[@name='lastName']")
    public WebElement lasttName;
    @FindBy(xpath = "//*[@type='submit']")
    public WebElement saveButton;
    @FindBy(xpath = "//input[@class='oxd-input oxd-input--active'])[2]")
    public WebElement employeeid;


    public addEmployeepage(){
        PageFactory.initElements(driver,this);
    }


}

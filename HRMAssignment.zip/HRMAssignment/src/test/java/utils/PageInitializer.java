package utils;

import pages.addEmployeepage;
import pages.loginPage;

public class PageInitializer {

public static loginPage loginPage;
   public static addEmployeepage addEmployeepage;

   public static void initializePageObject(){
       loginPage = new loginPage();
     addEmployeepage = new addEmployeepage();


   }
}

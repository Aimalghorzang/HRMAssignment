Feature:login validation scenarios

Background:

@emptyu
  Scenario: attemp login with empty username
  When the user attemps to log in with an empty username and a valid password
  And the user click on loging button
  Then the system displays an error message stating"Required"
  And the user should be able to correct their input and attempt to log in again

  @emptyP
  Scenario: Attempting login with an empty password field
    When the user attemps to log in with valid username and emtpy password
    And the user click on loging button
    Then the system displays an error message stating"Required"
    And the user should be able to correct their input and attempt to log in again

    @invalid
  Scenario: Attempting login with incorrect credentials
    When the user attemps to log in with invalid username and password
    And the user click on loging button
    Then the system displays an error message stating"Invalid credentials"
    And the user should be able to correct their input and attempt to log in again






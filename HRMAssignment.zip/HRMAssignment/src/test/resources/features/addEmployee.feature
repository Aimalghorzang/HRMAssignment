Feature: add employee to HRM application

  Background:
    And the user should be able to correct their input and attempt to log in again
    And the user click on loging button

    @name
  Scenario: user should be able to add employee to HRM application
    When user click on PIM option
    And user click on add employee option
    And user enter firstname and midlename and lastname
    And user click on save button
    Then employee is added successfully

    @byid
    Scenario:  add employee by unique user ID
      When user click on PIM option
      And user click on add employee option
      When user enter firstname and midlename and lastname and unique id
      And user click on save button
      Then employee is added successfully




